# AI 리터러시 연수 포스터 (GitHub Pages)

이 폴더는 GitHub Pages에 바로 올릴 수 있는 **정적 사이트** 형태입니다.

## 업로드 방법 (요약)
1. GitHub에서 새 저장소(repository) 생성
2. 이 폴더의 파일들을 저장소 루트에 업로드(커밋)
3. 저장소 **Settings → Pages**
4. **Source**: `Deploy from a branch`
5. **Branch**: `main` / **Folder**: `/ (root)` 선택 후 Save
6. 잠시 후 아래 주소로 접속:
   - `https://<깃헙아이디>.github.io/<저장소이름>/`

## 파일 구성
- `index.html` : 메인 페이지(포스터 문구)
- `README.md` : 업로드 안내
